from setuptools import setup,find_packages

setup(name="PyAutoSpeech",
version="0.1",
description="Package contains functionality for speech analysis",
Long_description="",
packages=['PyAutoSpeech'],
install_requires=["pydub",]
)